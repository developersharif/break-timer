from lib.src import *
print("trigared")
job()
